import './globals.css';
export const metadata={title:'SUPREME AI',description:'One AI. Every capability. Worldwide.'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
