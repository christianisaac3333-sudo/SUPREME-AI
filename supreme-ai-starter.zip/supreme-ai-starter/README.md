# SUPREME AI
A dark, responsive Next.js starter with a server-side AI chat endpoint.

## Run
- Node.js 20+
- `npm install`
- Copy `.env.example` to `.env.local` and add your provider key
- `npm run dev`

Deploy on Render with build `npm install && npm run build`, start `npm run start`. Set `OPENAI_API_KEY` in environment settings. Do not commit API keys.
