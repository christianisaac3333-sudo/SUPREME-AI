# SUPREME AI ♤
One AI. Every capability. Worldwide.

Next.js-powered AI chat starter with a premium dark interface. AI provider connection is configured through server-side environment variables.

## Deploy on Render
1. Connect this repository to Render and create a Web Service.
2. Build command: npm install && npm run build
3. Start command: npm run start
4. Set environment variables: AI_API_KEY, AI_BASE_URL (optional), AI_MODEL.

Never commit API keys. This starter currently provides chat; account system, persistent history, web research, image tools, and voice are future milestones.
